public class Assignment2 {
  public static void main(String[] args) {
    System.out.println();
    System.out.println();
    System.out.println();
    String line1 = "              *";
    String line2 = "             * *";
    String line3 = "            *   *";
    String line4 = "           *     *";
    String line5 = "          **** ****";
    System.out.println(line1);
    System.out.println(line2);
    System.out.println(line3);
    System.out.println(line4);
    System.out.println(line5);
    System.out.println(line2);
    System.out.println(line2);
    System.out.println(line2);
    System.out.println(line5);
    System.out.println(line4);
    System.out.println(line3);
    System.out.println(line2);
    System.out.println(line1);
  }
}
